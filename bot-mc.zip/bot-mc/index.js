const { Client, GatewayIntentBits, EmbedBuilder } = require("discord.js");
const axios = require("axios");
require("dotenv").config();

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

// Ganti dengan ID channel Discord kamu
const CHANNEL_ID = "1373325463132569671";

// Ganti dengan IP dan port server kamu
const SERVER_IP = "cj.bangisd.my.id";
const SERVER_PORT = "26715";

let statusMessage;

client.once("ready", async () => {
  console.log(`✅ Bot Ready! Logged in as ${client.user.tag}`);

  const channel = await client.channels.fetch(CHANNEL_ID);
  statusMessage = await channel.send("⏳ Mengambil status server...");

  // Update pertama
  updateStatus();

  // Update setiap 60 detik
  setInterval(updateStatus, 60 * 1000);
});

async function updateStatus() {
  try {
    const response = await axios.get(
      `https://api.mcstatus.io/v2/status/java/${SERVER_IP}:${SERVER_PORT}`,
    );
    const data = response.data;

    const statusOnline = data.online;
    const players = data.players;
    const motd = data.motd.clean || "";
    const ip = `${SERVER_IP}:${SERVER_PORT}`;

    const embed = new EmbedBuilder()
      .setTitle("🌐 Server Minecraft")
      .setColor(statusOnline ? 0x00ff00 : 0xff0000)
      .addFields(
        {
          name: "Status",
          value: statusOnline ? "🟢 Online" : "🔴 Offline",
          inline: true,
        },
        {
          name: "Players",
          value: `${players.online}/${players.max}`,
          inline: true,
        },
        { name: "IP Address", value: ip, inline: true },
        { name: "F8 Connect", value: `connect ${SERVER_IP}`, inline: false },
        {
          name: "Info",
          value: "🕒 Server akan di restart pukul **15.00 WIB**",
          inline: false,
        },
      )
      .setTimestamp();

    await statusMessage.edit({ content: "", embeds: [embed] });
  } catch (err) {
    console.error("[✖] Gagal update status:", err.message);
    if (statusMessage) {
      await statusMessage.edit({
        content: "❌ Gagal mengambil status server. Periksa koneksi atau IP.",
        embeds: [],
      });
    }
  }
}

// Login pakai token dari .env
client.login(process.env.TOKEN);
